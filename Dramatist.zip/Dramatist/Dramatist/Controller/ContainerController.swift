//
//  ContainerController.swift
//  Dramatist
//
//  Created by Gr.Skiy on 26.04.2020.
//  Copyright © 2020 Gr.Skiy. All rights reserved.
//

import UIKit

class ContainerController: UIViewController {
    
    //MARK: - Properties
    
    //MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //MARK:- Handlers
    
}

