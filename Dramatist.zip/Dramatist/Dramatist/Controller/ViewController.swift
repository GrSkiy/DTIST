//
//  ViewController.swift
//  Dramatist
//
//  Created by Gr.Skiy on 27.04.2020.
//  Copyright © 2020 Gr.Skiy. All rights reserved.
//

import Foundation

import UIKit

class ViewController: UIViewController {
    
    //MARK: - Properties
    
    //MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    //MARK:- Handlers
    
}
